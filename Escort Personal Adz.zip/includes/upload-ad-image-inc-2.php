<?php

require '../includes/upload-ad-image-inc.php';
