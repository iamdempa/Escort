<?php
ob_start();
require '../includes/remove-ad-image-inc.php';

ob_end_flush()();

