<!-- FOOTER -->
<footer class="container">                
    <p>&copy; 2017-2018 Escort Personal Adz, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
</footer>