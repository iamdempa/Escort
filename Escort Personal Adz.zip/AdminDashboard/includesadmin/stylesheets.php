
<link rel="stylesheet" href="cssadmin/style2.css">                  

<link rel="apple-touch-icon" href="apple-icon.png">
<link rel="shortcut icon" href="favicon.ico">

<link rel="stylesheet" href="cssadmin/bootstrap.min.css">
<!--<link rel="stylesheet" href="cssadmin/font-awesome.min.css">-->
<link rel="stylesheet" href="cssadmin/themify-icons.css">
<link rel="stylesheet" href="cssadmin/flag-icon.min.css">
<link rel="stylesheet" href="cssadmin/cs-skin-elastic.css">
<link rel="stylesheet" href="cssadmin/jqvmap.min.css">       

<link rel="stylesheet" href="cssadmin/style.css">

<link rel="stylesheet" href="cssadmin/ad/ad-custom.css">
<link rel="stylesheet" href="cssadmin/ad/ad-service-custom.css">
<link rel="stylesheet" href="cssadmin/ad/user-profile-custom.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>


