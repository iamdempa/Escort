<script src="jsadmin/jquery.min.js"></script>
<script src="jsadmin/popper.min.js"></script>
<script src="jsadmin/bootstrap.min.js"></script>
<script src="jsadmin/main.js"></script>


<script src="jsadmin/Chart.bundle.min.js"></script>
<script src="jsadmin/dashboard.js"></script>
<!--<script src="jsadmin/widgets.js"></script>-->
<script src="jsadmin/jquery.vmap.min.js"></script>
<script src="jsadmin/jquery.vmap.sampledata.js"></script>
<script src="jsadmin/jquery.vmap.world.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>